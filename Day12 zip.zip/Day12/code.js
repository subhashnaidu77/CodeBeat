const exp = require('express');
const app = exp();
const port = 3000;

// app.get('/',(req,res)=>{
// res.send("Welcome everyone ");
// });


// app.use((req,res,next)=>{
// console.log(`Time of ${new Date().toISOString()}`);
// next();


// });


app.use(exp.json());
// app.post('/data',(req,res)=>{

// console.log(req.body);
// res.send('data recieved')
// });


// app.get('/',(req,res)=>{
// res.send("Welcome everyone this a middleware");
// });
app.get('/',(req,res)=>{
res.send("welcome to the routing");
    });

app.post('/user',(req,res)=>{
console.log(req.body);
res.send(`user ${req.body.name}created`);
})

app.put('/user/:id',(req,res)=>{
    console.log(req.body);res.send(`user ${req.body.name} updated`)
});



app.listen(port,()=>{
console.log(`http://localhost:${port}`)})