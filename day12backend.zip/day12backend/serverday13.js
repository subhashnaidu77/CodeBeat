const express = require('express');
const mongoose = require('mongoose');
const userRoutes = require('./routes/userroutes');
const app = express();
app.use(express.json());

//routes
app.use('/api/users',userRoutes);
//mongo db connection
mongoose.connect('mongodb://localhost:27017/modularDB')
.then(()=>console.log('Mongo connected'))
.catch(err=>console.log(err));

//port 
app.listen(3000,()=>{
console.log('Server started')});