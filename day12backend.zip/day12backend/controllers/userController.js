const User = require('../models/userModel');

const getUser= async(req,res)=>{
const user = await User.find();
res.json(user);
}

const createUser= async (req,res)=>{
const {name,email}=req.body;
const user= new User({name,email});
await user.save();
res.status(201).json(user);
}

module.exports = {getUser,createUser};